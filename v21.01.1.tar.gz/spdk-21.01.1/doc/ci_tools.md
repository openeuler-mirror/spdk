# CI Tools {#ci_tools}

Section describing tools used by CI to verify integrity of the submitted
patches ([status](https://ci.spdk.io)).

- @subpage shfmt
