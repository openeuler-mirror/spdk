# Performance Reports {#performance_reports}

## Release 19.10

- [SPDK 19.10 Vhost Performance Report](https://dqtibwqq6s6ux.cloudfront.net/download/performance-reports/SPDK_vhost_perf_report_1910.pdf)
- [SPDK 19.10 NVMe-oF TCP Performance Report](https://dqtibwqq6s6ux.cloudfront.net/download/performance-reports/SPDK_nvmeof_tcp_perf_report_1910.pdf)
- [SPDK 19.10 NVMe-oF RDMA Performance Report](https://dqtibwqq6s6ux.cloudfront.net/download/performance-reports/SPDK_nvmeof_rdma_perf_report_1910.pdf)

## Release 19.07

- [SPDK 19.07 Vhost Performance Report](https://dqtibwqq6s6ux.cloudfront.net/download/performance-reports/SPDK_vhost_perf_report_19.07.pdf)
- [SPDK 19.07 NVMe-oF TCP Performance Report](https://dqtibwqq6s6ux.cloudfront.net/download/performance-reports/SPDK_nvmeof_tcp_perf_report_19.07.pdf)

## Release 19.04

- [SPDK 19.04 NVMe-oF RDMA Performance Report](https://dqtibwqq6s6ux.cloudfront.net/download/performance-reports/SPDK_19.04_NVMeOF_RDMA_benchmark_report.pdf)

## Release 19.01

- [SPDK 19.01.1 NVMe-oF RDMA Performance Report](https://dqtibwqq6s6ux.cloudfront.net/download/performance-reports/SPDK_nvmeof_perf_report_19.01.1.pdf)

## Release 18.04

- [SPDK 18.04 NVMe BDEV Performance Report](https://dqtibwqq6s6ux.cloudfront.net/download/performance-reports/SPDK_nvme_bdev_perf_report_18.04.pdf)
- [SPDK 18.04 NVMe-oF RDMA Performance Report](https://dqtibwqq6s6ux.cloudfront.net/download/performance-reports/SPDK_nvmeof_perf_report_18.04.pdf)

## Release 17.07

- [SPDK 17.07 vhost-scsi Performance Report](https://dqtibwqq6s6ux.cloudfront.net/download/performance-reports/SPDK17_07_vhost_scsi_performance_report.pdf)
